'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def financialManagement():
  totalBalance = 0
  for months in range(0,12):
    balance = float(input("Closing balance for this month: "))
    totalBalance = totalBalance + balance
  return round((totalBalance / 12), 2) 
  
# print(f"${financialManagement()}")


